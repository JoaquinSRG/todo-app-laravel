

<?php $__env->startSection('title', 'lista de tareas'); ?>

<?php $__env->startSection('content'); ?>

  <h1>Lista de Tareas</h1>

  <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary">Nueva tarea</a>

  <div style="margin-top: 20px;">
    <?php if($tasks->count() > 0): ?>
      <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div
          style="border: 1px solid #ddd; padding: 15px; margin-bottom: 10px; border-radius: 5px; background: <?php echo e($task->completed ? '#f0f0f0' : 'white'); ?>">
          <h3 style="margin-bottom: 10px; <?php echo e($task->completed ? 'text-decoration: line-through; color: #999;' : ''); ?>">
            <?php echo e($task->title); ?>

          </h3>

          <?php if($task->description): ?>
            <p style="color: #666; margin-bottom: 10px;"><?php echo e($task->description); ?></p>
          <?php endif; ?>
          <div style="margin-top: 10px">
            <a href="<?php echo e(route('tasks.show', $task)); ?>" class="btn btn-primary"
              style="font-size: 12px; padding: 5px 10px;">Ver</a>
            <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="btn btn-success"
              style="font-size: 12px; padding: 5px 10px;">Editar</a>

            <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" style="display: inline;">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger" style="font-size: 12px; padding: 5px 10px;"
                onclick="return confirm('¿Estás seguro?')">Eliminar</button>
            </form>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      <p style="margin-top: 20px; color: #666;">No hay tareas. Crea tu primera tarea!</p>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\joaqu\Desktop\todo-app\resources\views/tasks/index.blade.php ENDPATH**/ ?>