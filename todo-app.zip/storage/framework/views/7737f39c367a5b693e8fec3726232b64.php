

<?php $__env->startSection('title', 'Ver tarea'); ?>

<?php $__env->startSection('content'); ?>
  <h1>Detalles de la tarea</h1>
  <div
    style="border: 1px solid #ddd; padding: 20px; margin-top: 20px; border-radius: 5px; background: <?php echo e($task->completed ? '#f0f0f0' : 'white'); ?>">
    <h2 style="<?php echo e($task->title ? 'text-decoration: line-through; color: #999,' : ''); ?>"><?php echo e($task->title); ?></h2>
    <div style="margin-top: 15px">
      <strong>Estado:</strong>
      <?php if($task->completed): ?>
        <span style="color: green">Completada</span>
      <?php else: ?>
        <span style="color: orange">Pendiente</span>
      <?php endif; ?>
    </div>

    <?php if($task->description): ?>
      <div style="margin-top: 15px;">
        <strong>Descripcion:</strong>
        <p style="margin-top: 5px; color: #666;"><?php echo e($task->description); ?></p>
      </div>
    <?php endif; ?>

    <div style="margin-top: 15px;">
      <strong>Creada:</strong> <?php echo e($task->created_at->format('d/m/Y H:i')); ?>

    </div>

    <div style="margin-top: 15px;">
      <strong>Ultima actualizacion:</strong> <?php echo e($task->updated_at->format('d/m/Y H:i')); ?>

    </div>
  </div>

  <div style="margin-top: 20px">
    <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="btn btn-success">Editar</a>
    <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-secondary">Volver</a>

    <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="post" style="display: inline">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="btn btn-danger"
        onclick="return fonrim('Estas seguro de eliminar esta tarea?')">Eliminar</button>
    </form>
  </div>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\joaqu\Desktop\todo-app\resources\views/tasks/show.blade.php ENDPATH**/ ?>