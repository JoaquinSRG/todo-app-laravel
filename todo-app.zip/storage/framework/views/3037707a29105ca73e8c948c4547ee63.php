

<?php $__env->startSection('title', 'Nueva tarea'); ?>

<?php $__env->startSection('content'); ?>
  <h1>Crear nueva tarea</h1>

  <form action="<?php echo e(route('tasks.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="from-group">
      <label for="title">Titulo *</label>
      <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>" required>
      <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span style="color: red; font-size: 12px;"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
      <label for="description">Descripcion</label>
      <textarea name="description" id="description"><?php echo e(old('description')); ?></textarea>
      <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span style="color: red; font-size: 12px;"><?php echo e(message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div style="margin-top: 20px;">
      <button type="submit" class="btn btn-success">Guardar tarea</button>
      <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </div>
  </form>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\joaqu\Desktop\todo-app\resources\views/tasks/create.blade.php ENDPATH**/ ?>